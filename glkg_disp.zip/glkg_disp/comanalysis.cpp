#include "comanalysis.h"
#include "ui_comanalysis.h"

#include <QTime>
#include <QDebug>

ComAnalysis::ComAnalysis(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ComAnalysis)
{
    ui->setupUi(this);
    m_creatChart();

    ui->chkCurShowAng->setEnabled(false);
    ui->chkCurShowTor->setEnabled(false);
    ui->chkCurShowCur->setEnabled(false);

    connect(series1,&QSplineSeries::pressed,this,&ComAnalysis::axisY_torque);
    connect(series2,&QSplineSeries::pressed,this,&ComAnalysis::axisY_angel);
    connect(series3,&QSplineSeries::pressed,this,&ComAnalysis::axisY_current);

    connect(series4,&QSplineSeries::pressed,this,&ComAnalysis::axisY_torque);
    connect(series5,&QSplineSeries::pressed,this,&ComAnalysis::axisY_angel);
    connect(series6,&QSplineSeries::pressed,this,&ComAnalysis::axisY_current);


    ui->tableWidgetWaveFile->verticalHeader()->setVisible(false);   //隐藏列表头
    ui->tableWidgetWaveFile->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    setWindowTitle("隔离开关操作机构扭矩监测综合分析");
    connect(ui->tableWidgetWaveFile, SIGNAL(cellChanged(int,int)), this, SLOT(changeTest(int, int)));
    AddFileToTab();
    m_YBwaveData = ReadCurData("YangBenFile.dat");//读取样本文件中的录波数据


}

ComAnalysis::~ComAnalysis()
{
    delete ui;
}
void ComAnalysis::m_creatChart()
{
    chart->setTitle("");
    ui->chartViewAnalysis->setChart(chart);
    ui->chartViewAnalysis->setRenderHint(QPainter::Antialiasing);

    series1->setName("扭矩");
    series1->setPointsVisible(true);

    series2->setName("角度");
    series2->setPointsVisible(true);

    series3->setName("电流");
    series3->setPointsVisible(true);

    series4->setName("样本扭矩");
    series4->setPointsVisible(true);

    series5->setName("样本角度");
    series5->setPointsVisible(true);

    series6->setName("样本电流");
    series6->setPointsVisible(true);

    //绘制横纵坐标
    QPen pen1;
    pen1.setStyle(Qt::SolidLine);
    pen1.setWidth(2);
    pen1.setColor(Qt::black);
    series1->setPen(pen1);
    chart->addSeries(series1);

    QPen pen2;
    pen2.setStyle(Qt::SolidLine);
    pen2.setWidth(2);
    pen2.setColor(Qt::green);
    series2->setPen(pen2);
    chart->addSeries(series2);

    QPen pen3;
    pen3.setStyle(Qt::SolidLine);
    pen3.setWidth(2);
    pen3.setColor(Qt::blue);
    series3->setPen(pen3);
    chart->addSeries(series3);

    QPen pen4;
    pen4.setStyle(Qt::DashLine);
    pen4.setWidth(2);
    pen4.setColor(Qt::black);
    series4->setPen(pen4);
    chart->addSeries(series4);

    QPen pen5;
    pen5.setStyle(Qt::DashLine);
    pen5.setWidth(2);
    pen5.setColor(Qt::green);
    series5->setPen(pen5);
    chart->addSeries(series5);

    QPen pen6;
    pen6.setStyle(Qt::DashLine);
    pen6.setWidth(2);
    pen6.setColor(Qt::blue);
    series6->setPen(pen6);
    chart->addSeries(series6);

//当前坐标轴  横坐标
      axisX->setRange(0,100);//设置坐标范围
      axisX->setLabelFormat("%d");
      axisX->setTickCount(11);//主分隔个数
      axisX->setMinorTickCount(0);
      axisX->setTitleText("时间(s)");

//扭矩纵坐标
      axisY1->setRange(0,1000);//设置坐标范围
      axisY1->setLabelFormat("%d");
      axisY1->setTickCount(15);//主分隔个数
      axisY1->setMinorTickCount(0);
      axisY1->setTitleText("扭矩(N)");
      axisY1->setLinePenColor(Qt::black);

//角度纵坐标
      axisY2->setRange(0,200);//设置坐标范围
      axisY2->setLabelFormat("%d");
      axisY2->setTickCount(15);//主分隔个数
      axisY2->setMinorTickCount(0);
      axisY2->setTitleText("角度(θ)");
      axisY2->setLabelsVisible(false);
      axisY2->setTitleVisible(false);
      axisY2->setVisible(false);
      axisY2->setLinePenColor(Qt::green);//坐标轴颜色

//电流纵坐标
      axisY3->setRange(0,100);//设置坐标范围
      axisY3->setLabelFormat("%.2f");
      axisY3->setTickCount(11);//主分隔个数
      axisY3->setMinorTickCount(0);
      axisY3->setTitleText("电流(A)");
      axisY3->setLabelsVisible(false);
      axisY3->setTitleVisible(false);
      axisY3->setVisible(false);
      axisY3->setLinePenColor(Qt::blue);

      chart->setAxisX(axisX,series1);//设置X坐标
      chart->setAxisY(axisY1,series1);//设置Y坐标

      chart->setAxisX(axisX,series2);
      chart->setAxisY(axisY2,series2);

      chart->setAxisX(axisX,series3);
      chart->setAxisY(axisY3,series3);


      chart->setAxisX(axisX,series4);//设置X坐标
      chart->setAxisY(axisY1,series4);//设置Y坐标

      chart->setAxisX(axisX,series5);
      chart->setAxisY(axisY2,series5);

      chart->setAxisX(axisX,series6);
      chart->setAxisY(axisY3,series6);
}

void ComAnalysis::axisY_torque()
{
    axisY1->setLabelsVisible(true);
    axisY1->setTitleVisible(true);
    axisY1->setVisible(true);
    axisY2->setLabelsVisible(false);
    axisY2->setTitleVisible(false);
    axisY2->setVisible(false);
    axisY3->setLabelsVisible(false);
    axisY3->setTitleVisible(false);
    axisY3->setVisible(false);
}
void ComAnalysis::axisY_angel()
{
   axisY2->setLabelsVisible(true);//量程可见性
   axisY2->setTitleVisible(true);//坐标轴可见性
   axisY2->setVisible(true);//坐标轴可见性
   axisY1->setLabelsVisible(false);
   axisY1->setTitleVisible(false);
   axisY1->setVisible(false);
   axisY3->setLabelsVisible(false);
   axisY3->setTitleVisible(false);
   axisY3->setVisible(false);

}
void ComAnalysis::axisY_current()
{
    axisY3->setLabelsVisible(true);
    axisY3->setTitleVisible(true);
    axisY3->setVisible(true);
    axisY1->setLabelsVisible(false);
    axisY1->setTitleVisible(false);
    axisY1->setVisible(false);
    axisY2->setLabelsVisible(false);
    axisY2->setTitleVisible(false);
    axisY2->setVisible(false);
}

void ComAnalysis::normal()
{
    ui->textEditConclusion->clear();
    ui->textEditConclusion->setText("开关扭矩监测正常");
}
void ComAnalysis::abnormal()
{
    ui->textEditConclusion->clear();
    ui->textEditConclusion->setText("开关扭矩监测异常超值报警，因转动部分卡滞导致开关操作扭矩增大，建议检查调试");
}

//在界面表格中显示录波文件目录下的文件
//利用devwave中的WaveFileQuery()和WaveFileGetNum()函数
void ComAnalysis::AddFileToTab()
{
    m_WaveFile.WaveFileQuery(m_filename);
    int num = m_WaveFile.WaveFileGetNum();
    for(int i=0;i<num;i++)
    {
        ui->tableWidgetWaveFile->setRowCount(num);
        ui->tableWidgetWaveFile->insertRow(i);
        QTableWidgetItem *check=new QTableWidgetItem;
        check->setCheckState (Qt::Unchecked);
        ui->tableWidgetWaveFile->setItem(i,0,new QTableWidgetItem(QString::number(i+1)));
        ui->tableWidgetWaveFile->setItem(i,1,new QTableWidgetItem(m_filename[i]));
        ui->tableWidgetWaveFile->setItem(i,2,check); //插入复选框
    }
}

//当tablewidget中的复选框状态发射变化时，运行该槽函数
void ComAnalysis::changeTest(int row, int column)
{
    if(ui->tableWidgetWaveFile->item(row, column)->checkState()==Qt::Checked)
    {
        ui->chkCurShowAng->setEnabled(true);
        ui->chkCurShowTor->setEnabled(true);
        ui->chkCurShowCur->setEnabled(true);

        QString Filename;
        Filename = ui->tableWidgetWaveFile->item(row,column-1)->text();
        m_waveData = ReadCurData(Filename);
    }
    else if(ui->tableWidgetWaveFile->item(row, column)->checkState()==Qt::Unchecked)
    {
        ui->chkCurShowAng->setEnabled(false);
        ui->chkCurShowTor->setEnabled(false);
        ui->chkCurShowCur->setEnabled(false);

        ui->chkCurShowAng->setCheckState(Qt::Unchecked);
        ui->chkCurShowTor->setCheckState(Qt::Unchecked);
        ui->chkCurShowCur->setCheckState(Qt::Unchecked);

        series1->clear();
        series2->clear();
        series3->clear();
    }

}
/*
 * 当前波形的显示：
 * ReadCurData===>读取文件中的波形数据
 * 扭矩叠加chkCurShowTor
 * 角度叠加
 * 电流叠加
*/
WaveData_t ComAnalysis::ReadCurData(QString Filename)
{
    WaveData_t waveData;
    WaveData_t YBwaveData;
    if(Filename == "YangBenFile.dat")
    {
        m_YBWaveFile.WaveFileExport(Filename,&YBwaveData);
        return  YBwaveData;
    }
    else
    {
       m_WaveFile.WaveFileExport(Filename,&waveData);
       return waveData;
    }

}


void ComAnalysis::on_chkCurShowTor_stateChanged(int arg1)
{
    if(ui->chkCurShowTor->checkState()==Qt::Checked){
         for(int i=0;i<101;i+=10){
             int tor;
             tor = m_waveData.Tor[i];
             series1->append(i,tor);
          }
    }
    else if(ui->chkCurShowTor->checkState()==Qt::Unchecked){
        series1->clear();
    }

}

void ComAnalysis::on_chkCurShowAng_stateChanged(int arg1)
{
    if(ui->chkCurShowAng->checkState()==Qt::Checked){
         for(int i=0;i<101;i+=10){
             int ang;
             ang = m_waveData.Ang[i];
             series2->append(i,ang);
          }
    }
    else if(ui->chkCurShowAng->checkState()==Qt::Unchecked){
        series2->clear();
    }
}

void ComAnalysis::on_chkCurShowCur_stateChanged(int arg1)
{
    if(ui->chkCurShowCur->checkState()==Qt::Checked){
         for(int i=0;i<101;i+=10){
             int cur;
             cur = m_waveData.Cur[i];
             series3->append(i,cur);
          }
    }
    else if(ui->chkCurShowCur->checkState()==Qt::Unchecked){
        series3->clear();
    }
}


void ComAnalysis::on_chkYangShowTor_stateChanged(int arg1)
{
    if(ui->chkYangShowTor->checkState()==Qt::Checked)
    {

         for(int i=0;i<101;i+=10){
             int tor;
             tor = m_YBwaveData.Tor[i];
             series4->append(i,tor);
         }

    }
    else if(ui->chkYangShowTor->checkState()==Qt::Unchecked){
             series4->clear();
         }

}

void ComAnalysis::on_chkYangShowAng_stateChanged(int arg1)
{
    if(ui->chkYangShowAng->checkState()==Qt::Checked){
         for(int i=0;i<101;i+=10){
             int ang;
             ang = m_YBwaveData.Ang[i];
             series5->append(i,ang);
          }
    }
    else if(ui->chkYangShowAng->checkState()==Qt::Unchecked){
        series5->clear();
    }
}

void ComAnalysis::on_chkYangShowCur_stateChanged(int arg1)
{
    if(ui->chkYangShowCur->checkState()==Qt::Checked){
         for(int i=0;i<101;i+=10){
             int cur;
             cur = m_YBwaveData.Cur[i];
             series6->append(i,cur);
          }
    }
    else if(ui->chkYangShowCur->checkState()==Qt::Unchecked){
        series6->clear();
    }
}
