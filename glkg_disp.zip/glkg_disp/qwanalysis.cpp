#include "qwanalysis.h"
#include "ui_qwanalysis.h"

QWAnalysis::QWAnalysis(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QWAnalysis)
{
    ui->setupUi(this);
    ui->gridLayout->setAlignment(Qt::AlignHCenter|Qt::AlignVCenter);
    //添加标题
    setWindowTitle(QString("隔离开关操作机构箱内温湿度监测综合分析"));
}

QWAnalysis::~QWAnalysis()
{
    delete ui;
}

void QWAnalysis::TemperatureHight()
{
    ui->textEditTER->clear();
    ui->textEditTER->setText("高温报警启动风扇");
}

void QWAnalysis::TemperatureNormal()
{
    ui->textEditTER->clear();
    ui->textEditTER->setText("温度正常");
}
void QWAnalysis::TemperatureLow()
{
    ui->textEditTER->clear();
    ui->textEditTER->setText("低温报警启动加热");
}

void QWAnalysis::HumidityHight()
{
    ui->textEditHUM->clear();
    ui->textEditHUM->setText("高湿报警启动风吹机");
}
void QWAnalysis::HumidityNormal()
{
    ui->textEditHUM->clear();
    ui->textEditHUM->setText("湿度正常");
}
