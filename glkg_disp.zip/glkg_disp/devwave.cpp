#include "devwave.h"
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDebug>

Devwave::Devwave()
{
}

Devwave::~Devwave()
{
}

int Devwave::Init(void)
{
    int     ret = -1;
    QDir    dir;

    m_WaveFileNO = 0;
    m_WaveFileNum = 0;

    dir.setPath(DEV_WAVE_DIR);
    if(!dir.exists())
        dir.mkpath(DEV_WAVE_DIR);

    dir.setPath(DEV_WAVE_YDIR);
    if(!dir.exists())
        dir.mkpath(DEV_WAVE_YDIR);

    return ret;
}

int Devwave::WaveFileImport(QString fileName, WaveData_t* waveData)
{
    int         ret = -1;
    QFile       file;
    QString     filePath;
    bool        fileRet = false;

    if(fileName == "YangBenFile.dat")
    {
        filePath = DEV_WAVE_YDIR;
    }
    else
    {
        filePath = DEV_WAVE_DIR;
    }
    filePath.append(fileName);

    file.setFileName(filePath);

    fileRet = file.open(QIODevice::ReadWrite  | QIODevice::Text);

    if (fileRet)
    {
        file.write((const char *)waveData, sizeof(WaveData_t));
        fileRet = file.waitForBytesWritten(1000);
        ret = (int)fileRet;
        if(fileRet)
            devwave_debug("Wave File Write Successed \r\n");
        else
            devwave_debug("Wave File Write Errored \r\n");
    }

    return ret;
}

int Devwave::WaveFileExport(QString fileName, WaveData_t* waveData)
{
    int         ret = -1;
    QFile       file;
    QString     filePath;
    bool        fileRet = false;

    if(fileName == "YangBenFile.dat")
    {
        filePath = DEV_WAVE_YDIR;
    }
    else
    {
        filePath = DEV_WAVE_DIR;
    }
    filePath.append(fileName);
    file.setFileName(filePath);

    fileRet = file.open(QIODevice::ReadWrite  | QIODevice::Text);
    if (fileRet)
    {
        fileRet = file.read((char *)waveData, sizeof(WaveData_t));
        ret = (int)fileRet;
        if(fileRet)
            devwave_debug("Wave File read Successed \r\n");
        else
            devwave_debug("Wave File read Errored \r\n");
    }

    return ret;
}

int Devwave::WaveFileQuery(QString fileName[])
{
    QDir            dir;
    QFileInfoList   fileInfoList;

    dir.setPath(DEV_WAVE_DIR);
    fileInfoList = dir.entryInfoList(QDir::Files | QDir::Hidden | QDir::NoSymLinks);

    for(int i=0; i<fileInfoList.size(); i++)
    {
        fileName[i] = fileInfoList.at(i).fileName();
    }

    return 1;
}

int Devwave::WaveFileClrNO(void)
{
    int ret = -1;

    m_WaveFileNO = 0;

    return ret;
}

int Devwave::WaveFileClear(void)
{
    int     ret = -1;
    QDir    dir;

    dir.setPath(DEV_WAVE_DIR);
    if(dir.exists())
        dir.rmdir(DEV_WAVE_DIR);

    if(!dir.exists())
        dir.mkdir(DEV_WAVE_DIR);

    ret = 1;
    return ret;
}

int Devwave::WaveFileGetNum()
{
    QFileInfoList   fileInfoList;
    QDir            dir;

    dir.setPath(DEV_WAVE_DIR);
    fileInfoList = dir.entryInfoList(QDir::Files | QDir::Hidden | QDir::NoSymLinks);
    m_WaveFileNum = fileInfoList.size();

    return m_WaveFileNum;
}

QString Devwave::WaveFileCurrent()
{
    int currentNo = 0;

    QString fileName[DEV_WAVE_FILE_MAX];

    WaveFileQuery(fileName);

    currentNo = WaveFileGetNum() - 1;

    return fileName[currentNo];
}
