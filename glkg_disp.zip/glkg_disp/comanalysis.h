#ifndef COMANALYSIS_H
#define COMANALYSIS_H

#include <QDialog>
#include <QtCharts/QChartView>
#include<QtCharts/QSplineSeries>
#include <QtCharts/QValueAxis>
#include <QTimer>

#include "devwave.h"

using namespace QtCharts;
namespace Ui {
class ComAnalysis;
}

class ComAnalysis : public QDialog
{
    Q_OBJECT

public:
    explicit ComAnalysis(QWidget *parent = 0);
    ~ComAnalysis();

    void normal();//扭矩正常
    void abnormal();//扭矩异常
    void AddFileToTab();

private slots:
    void changeTest(int row, int column);

    void on_chkCurShowTor_stateChanged(int arg1);

    void on_chkCurShowAng_stateChanged(int arg1);

    void on_chkCurShowCur_stateChanged(int arg1);

    void on_chkYangShowTor_stateChanged(int arg1);

    void on_chkYangShowAng_stateChanged(int arg1);

    void on_chkYangShowCur_stateChanged(int arg1);

    void axisY_angel();
    void axisY_torque();
    void axisY_current();

signals:


private:
    //创建图表
    void m_creatChart();
    //从文件中读取当前数据，并显示
   WaveData_t ReadCurData(QString Filename);

private:
    Ui::ComAnalysis *ui;

    QSplineSeries *series1=new QSplineSeries(this);//创建数据点
    QSplineSeries *series2=new QSplineSeries(this);
    QSplineSeries *series3=new QSplineSeries(this);
    QSplineSeries *series4=new QSplineSeries(this);
    QSplineSeries *series5=new QSplineSeries(this);
    QSplineSeries *series6=new QSplineSeries(this);

    QChart *chart=new QChart;
    int rows=1;
    Devwave m_WaveFile;
    WaveData_t m_waveData;

    Devwave m_YBWaveFile;
    WaveData_t m_YBwaveData;
    QString m_filename[100];

public:
    QValueAxis *axisX=new QValueAxis(this);
    QValueAxis *axisY1=new QValueAxis(this);
    QValueAxis *axisY2=new QValueAxis(this);
    QValueAxis *axisY3=new QValueAxis(this);

};

#endif // COMANALYSIS_H
