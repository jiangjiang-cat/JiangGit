#ifndef QPHANALYSIS_H
#define QPHANALYSIS_H

#include <QDialog>

namespace Ui {
class QPHAnalysis;
}

class QPHAnalysis : public QDialog
{
    Q_OBJECT

public:
    explicit QPHAnalysis(QWidget *parent = nullptr);
    ~QPHAnalysis();

private:
    Ui::QPHAnalysis *ui;
};

#endif // QPHANALYSIS_H
