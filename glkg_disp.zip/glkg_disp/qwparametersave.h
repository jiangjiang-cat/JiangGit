#ifndef QWPARAMETERSAVE_H
#define QWPARAMETERSAVE_H

#include <QDialog>

#define ADDR_HigtWARN 0x4000
#define ADDR_LOWWARN 0x4001
#define ADDR_HUMWARN 0x4002

namespace Ui {
class QWParameterSave;
}

class QWParameterSave : public QDialog
{
    Q_OBJECT

public:
    explicit QWParameterSave(QWidget *parent = nullptr);
    ~QWParameterSave();

    int HigtValue=0,LowValue=0,HumValue=0;


private slots:
    void on_btnParameterSave_clicked();


signals:
    //void sendData(int HigtValue);

private:
    Ui::QWParameterSave *ui;
};

#endif // QWPARAMETERSAVE_H
