#include "qphanalysis.h"
#include "ui_qphanalysis.h"

QPHAnalysis::QPHAnalysis(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QPHAnalysis)
{
    ui->setupUi(this);
}

QPHAnalysis::~QPHAnalysis()
{
    delete ui;
}
