#include "qphparametersave.h"
#include "ui_qphparametersave.h"

QPHParameterSave::QPHParameterSave(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QPHParameterSave)
{
    ui->setupUi(this);
}

QPHParameterSave::~QPHParameterSave()
{
    delete ui;
}
