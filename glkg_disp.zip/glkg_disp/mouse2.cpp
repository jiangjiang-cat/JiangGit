#include "mouse2.h"

#include<QMouseEvent>
#include<QDebug>

mouse2::mouse2(QWidget *parent) : QWidget(parent)
{
    this->setMouseTracking(true);//设置追踪鼠标
}
void mouse2::mousePressEvent(QMouseEvent *event)
{

//    mytorque->setWindowState(Qt::WindowMaximized);
    mytorque->exec();
    mytorque->chart->zoomReset();
}
