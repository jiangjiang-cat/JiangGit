#ifndef QPHPARAMETERSAVE_H
#define QPHPARAMETERSAVE_H

#include <QDialog>

namespace Ui {
class QPHParameterSave;
}

class QPHParameterSave : public QDialog
{
    Q_OBJECT

public:
    explicit QPHParameterSave(QWidget *parent = nullptr);
    ~QPHParameterSave();

private:
    Ui::QPHParameterSave *ui;
};

#endif // QPHPARAMETERSAVE_H
