#include "torquedetection.h"
#include "ui_torquedetection.h"

#include<QTime>
#include <QDebug>
#include <QMessageBox>

torqueDetection::torqueDetection(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::torqueDetection)
{
    ui->setupUi(this);

    setWindowTitle("隔离开关操作机构扭矩监测界面");    
    torqueInit();

    connect(series1,&QSplineSeries::pressed,this,&torqueDetection::axisY_torque);
    connect(series2,&QSplineSeries::pressed,this,&torqueDetection::axisY_angel);
    connect(series3,&QSplineSeries::pressed,this,&torqueDetection::axisY_current);

    connect(series1,&QSplineSeries::hovered,this,&torqueDetection::toolTip1);
    connect(series2,&QSplineSeries::hovered,this,&torqueDetection::toolTip2);
    connect(series3,&QSplineSeries::hovered,this,&torqueDetection::toolTip3);
}

torqueDetection::~torqueDetection()
{
    delete ui;
}
void torqueDetection::sleep(unsigned int msec)//延时函数（测试）
{
    QTime reachTime=QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<reachTime)
    QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

void torqueDetection::torqueInit()
{
    creatChart();
    chart->zoomReset();

}
void torqueDetection::creatChart()//创建图表
{   
    chart->setTitle("");
    ui->chartviewMonitor->setChart(chart);
    ui->chartviewMonitor->setRenderHint(QPainter::Antialiasing);

    series1->setName("扭矩");
    series1->setPointsVisible(true);

    series2->setName("角度");
    series2->setPointsVisible(true);

    series3->setName("电流");
    series3->setPointsVisible(true);

    //绘制横纵坐标
    QPen pen;
    pen.setStyle(Qt::SolidLine);
    pen.setWidth(2);
    pen.setColor(Qt::black);
    series1->setPen(pen);
    chart->addSeries(series1);
    QPen pen1;
    pen1.setStyle(Qt::SolidLine);
    pen1.setWidth(2);
    pen1.setColor(Qt::green);
    series2->setPen(pen1);
    chart->addSeries(series2);

    QPen pen2;
    pen2.setStyle(Qt::SolidLine);
    pen2.setWidth(2);
    pen2.setColor(Qt::blue);
    series3->setPen(pen2);
    chart->addSeries(series3);

//当前坐标轴  横坐标
      axisX->setRange(0,100);//设置坐标范围
      axisX->setLabelFormat("%d");
      axisX->setTickCount(11);//主分隔个数
      axisX->setMinorTickCount(0);
      axisX->setTitleText("时间(s)");

//扭矩纵坐标
      axisY->setRange(0,1000);//设置坐标范围
      axisY->setLabelFormat("%d");
      axisY->setTickCount(21);//主分隔个数
      axisY->setMinorTickCount(0);
      axisY->setTitleText("扭矩(N)");
      axisY->setLinePenColor(Qt::black);

//角度纵坐标
      axisY1->setRange(0,200);//设置坐标范围
      axisY1->setLabelFormat("%d");
      axisY1->setTickCount(21);//主分隔个数
      axisY1->setMinorTickCount(0);
      axisY1->setTitleText("角度(θ)");
      axisY1->setLabelsVisible(false);
      axisY1->setTitleVisible(false);
      axisY1->setVisible(false);
      axisY1->setLinePenColor(Qt::green);//坐标轴颜色

//电流纵坐标
      axisY2->setRange(0,100);//设置坐标范围
      axisY2->setLabelFormat("%.2f");
      axisY2->setTickCount(21);//主分隔个数
      axisY2->setMinorTickCount(0);
      axisY2->setTitleText("电流(A)");
      axisY2->setLabelsVisible(false);
      axisY2->setTitleVisible(false);
      axisY2->setVisible(false);
      axisY2->setLinePenColor(Qt::blue);

      chart->setAxisX(axisX,series1);//设置X坐标
      chart->setAxisY(axisY,series1);//设置Y坐标

      chart->setAxisX(axisX,series2);
      chart->setAxisY(axisY1,series2);

      chart->setAxisX(axisX,series3);
      chart->setAxisY(axisY2,series3);


}

void torqueDetection::axisY_torque()
{
    axisY->setLabelsVisible(true);
    axisY->setTitleVisible(true);
    axisY->setVisible(true);
    axisY1->setLabelsVisible(false);
    axisY1->setTitleVisible(false);
    axisY1->setVisible(false);
    axisY2->setLabelsVisible(false);
    axisY2->setTitleVisible(false);
    axisY2->setVisible(false);
}
void torqueDetection::axisY_angel()
{
   axisY1->setLabelsVisible(true);//量程可见性
   axisY1->setTitleVisible(true);//坐标轴可见性
   axisY1->setVisible(true);//坐标轴可见性
   axisY->setLabelsVisible(false);
   axisY->setTitleVisible(false);
   axisY->setVisible(false);
   axisY2->setLabelsVisible(false);
   axisY2->setTitleVisible(false);
   axisY2->setVisible(false);

}
void torqueDetection::axisY_current()
{
    axisY2->setLabelsVisible(true);
    axisY2->setTitleVisible(true);
    axisY2->setVisible(true);
    axisY->setLabelsVisible(false);
    axisY->setTitleVisible(false);
    axisY->setVisible(false);
    axisY1->setLabelsVisible(false);
    axisY1->setTitleVisible(false);
    axisY1->setVisible(false);
}

void torqueDetection::dataplot_torque(int n, int m)
{
   series1->append(n,m);
}
void torqueDetection::dataplot_angel(int n, int m)
{
    series2->append(n,m);
}
void torqueDetection::dataplot_current(int n, int m)
{
    series3->append(n,m);
}

void torqueDetection::SaveWavedata(WaveData_t *wavedata)
{
  m_wavedata =wavedata;
}

void torqueDetection::on_btsetdata_clicked()//设置参数
{
   m_setdata->setFocus();
   m_setdata->exec();
}
void torqueDetection::on_btanalysis_clicked()//数据分析窗口
{
    analysis->show();
}

void torqueDetection::on_btpreservation_clicked()//数据存储为样本
{
   QString fileName;
    fileName = "YangBenFile.dat";
    m_WaveFile->WaveFileImport(fileName,m_wavedata);
    QMessageBox::about(this, tr("About消息框"), tr("保存成功！"));
}

void torqueDetection::on_btdataclear_clicked()
{

}

void torqueDetection::toolTip1(QPointF point, bool state)
{
    if (m_tooltip == 0)
        m_tooltip = new Callout(chart);
    if (state)
    {
        m_tooltip->setText(QString("时间:%1 \n扭矩:%2 ").arg(point.x()).arg(point.y()));
        ui->lineTorqueal->clear();
        ui->lineTorqueal->setText(QString("%1").arg(point.y()));
        m_tooltip->setAnchor(point);//传入点的值
        m_tooltip->updateGeometry();//更新数据点数值
        m_tooltip->show();
    }
    else
    {
        m_tooltip->hide();
    }
}

void torqueDetection::toolTip2(QPointF point, bool state)
{
    if (m_tooltip == 0)
        m_tooltip = new Callout(chart);
    if (state)
    {
        m_tooltip->setText(QString("时间:%1 \n角度:%2 ").arg(point.x()).arg(point.y()));
        ui->lineAngle->clear();
        ui->lineAngle->setText(QString("%1").arg(point.y()));
        m_tooltip->setAnchor(point);
        m_tooltip->updateGeometry();
        m_tooltip->show();
    }
    else
    {
        m_tooltip->hide();
    }
}
void torqueDetection::toolTip3(QPointF point, bool state)
{
    if (m_tooltip == 0)
        m_tooltip = new Callout(chart);
    if (state)
    {
        m_tooltip->setText(QString("时间:%1 \n电流:%2 ").arg(point.x()).arg(point.y()));
        ui->lineCurrent->clear();
        ui->lineCurrent->setText(QString("%1").arg(point.y()));
        m_tooltip->setAnchor(point);
        m_tooltip->updateGeometry();
        m_tooltip->show();
    }
    else
    {
        m_tooltip->hide();
    }
}
void torqueDetection::wheelEvent(QWheelEvent *event)
{
  if (event->delta() > 0)
    {//放大
         chart->zoom(1.1);
    }
    else
    {//缩小
         chart->zoom(0.9);
    }
}

