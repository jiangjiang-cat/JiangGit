#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "ctemprmtp.h"

#include "modbuspro.h"
#include "sgmdb.h"
#include "devwave.h"
#include "devoper.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    initTerminal();

    connect(ui->dashtem1,SIGNAL(sendData(int)),this,SLOT(changeTem(int)));
    connect(ui->dashHum1,SIGNAL(sendData(int)),this,SLOT(changeHum(int)));

    connect(series1,&QSplineSeries::pressed,this,&MainWindow::axisY_angel);
    connect(series2,&QSplineSeries::pressed,this,&MainWindow::axisY_current);

    connect(ui->widget2->mytorque->m_setdata,SIGNAL(MaxTorChange()),this,SLOT(updateChartTor()));
    connect(ui->widget3->mytorque->m_setdata,SIGNAL(MaxTorChange()),this,SLOT(updateChartTor1()));

    connect(m_timer,SIGNAL(timeout()), this, SLOT(m_timerSlot()));
    m_timer->start(1000);

    GetDataFromWaveFile();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initTerminal()
{
    //将label文字居中显示
    ui->label->setAlignment(Qt::AlignCenter);
    ui->label_2->setAlignment(Qt::AlignCenter);
    //将表盘居中显示
    ui->verticalLayout_5->setAlignment(Qt::AlignCenter);
    ui->verticalLayout_6->setAlignment(Qt::AlignCenter);

    //扭矩窗口居中
    ui->groupBox->setAlignment(Qt::AlignCenter);

    //电流窗口曲线图居中显示
    ui->groupBox_2->setAlignment(Qt::AlignCenter);

    //窗口最大化
   setWindowState(Qt::WindowMaximized);

    //设置窗口的qss样式
    setWindowStyle();

    //初始化扭矩和电流的波形图表格
    creatChart();

    //创建波形图
    createWaveFile();
}



void MainWindow::m_timerSlot()
{
   GetTemFromTab();
   GetHumFromTab();

   if (g_aTempImg.size().width() > 100)
   {
        ui->label_3->setPixmap(QPixmap::fromImage(g_aTempImg.scaled(ui->label_3->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
   }
   if (g_bTempImg.size().width() > 100)
   {
       ui->label_4->setPixmap(QPixmap::fromImage(g_bTempImg.scaled(ui->label_4->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
   }
   if (g_cTempImg.size().width() > 100)
   ui->label_5->setPixmap(QPixmap::fromImage(g_cTempImg.scaled(ui->label_5->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));

}
//从数据库中获取温度，湿度值
int MainWindow::GetTemFromTab()
{
    int ret = -1,Tvalue =0;
    g_Devoper->getDevDBObjData(ADDR_TER,&Tvalue);
    ui->dashtem1->setValue(Tvalue);
    ret=1;
    return ret;
}
int MainWindow::GetHumFromTab()
{
    int ret = -1,Hvalue=0;
    g_Devoper->getDevDBObjData(ADDR_HUM,&Hvalue);
    ui->dashHum1->setValue(Hvalue);
    ret=1;
    return ret;
}

//从录波文件中读取数据并在界面上显示波形（扭矩，电流，角度）
int MainWindow::GetDataFromWaveFile()
{
    WaveData_t waveData;
    QString fileName = g_Devwave->WaveFileCurrent();
    int tor,ang,cur;

    m_WaveFile->WaveFileExport(fileName,&waveData);
    ui->widget2->mytorque->SaveWavedata(&waveData);
    ui->widget3->mytorque->SaveWavedata(&waveData);
    for(int i=0; i<101; i+=10)
    {
        tor = waveData.Tor[i];
        ang = waveData.Ang[i];
        cur = waveData.Cur[i];
        dataplot_torque(i,tor);
        dataplot_angel(i,ang);
        dataplot_current(i,cur);
    }

    return 1;
}

//温度表盘值的改变
void MainWindow::changeTem(int data)
{

  //  修改子窗口的温度表盘上的值，使其与主窗口数值保持同步
    ui->widget1->myparameter->TemData(data);

}
//湿度表盘值的改变
void MainWindow::changeHum(int data)
{

  //  修改子窗口的湿度表盘上的值，使其与主窗口数值保持同步
    ui->widget1->myparameter->HumData(data);

}

void MainWindow::creatChart()
{
    //绘制扭矩波形图表格
    chartTor->setTitle("");
    ui->chartview->setChart(chartTor);
    ui->chartview->setRenderHint(QPainter::Antialiasing);

    series->setName("扭矩");
    series->setPointsVisible(true);

    QMargins marg(10, 10, 10, 10);
    chartTor->setMargins(marg);

    QPen pen;
    pen.setStyle(Qt::SolidLine);
    pen.setWidth(2);
    pen.setColor(Qt::black);
    series->setPen(pen);
    chartTor->addSeries(series);

    axisX->setRange(0,100);//设置坐标范围
    axisX->setLabelFormat("%d");
    axisX->setTickCount(11);//主分隔个数
    axisX->setMinorTickCount(0);
    axisX->setTitleText("时间(s)");

    chartTor->setAxisX(axisX,series);//设置X坐标

    axisY->setRange(0,1000);
    axisY->setLabelFormat("%d");
    axisY->setTickCount(11);
    axisY->setMinorTickCount(0);
    axisY->setTitleText("扭矩(N*m)");

    //绘制角度、电流波形图表格
    chartAnlCur->setTitle("");
    ui->chartview1->setChart(chartAnlCur);
    ui->chartview1->setRenderHint(QPainter::Antialiasing);

    series1->setName("角度");
    series2->setName("电流");
    series1->setPointsVisible(true);
    series2->setPointsVisible(true);

    chartAnlCur->setMargins(marg);

    QPen p1;
    p1.setStyle(Qt::SolidLine);
    p1.setWidth(2);
    p1.setColor(Qt::green);
    series1->setPen(p1);
    chartAnlCur->addSeries(series1);

    QPen p2;
    p2.setStyle(Qt::SolidLine);
    p2.setWidth(2);
    p2.setColor(Qt::blue);
    series2->setPen(p2);
    chartAnlCur->addSeries(series2);

    axisX1->setRange(0,100);//设置坐标范围
    axisX1->setLabelFormat("%d");
    axisX1->setTickCount(11);
    axisX1->setMinorTickCount(0);
    axisX1->setTitleText("时间(s)");
    axisX1->setLabelsVisible(false);

    chartAnlCur->setAxisX(axisX1,series1);
    chartAnlCur->setAxisX(axisX1,series2);

    axisY1->setRange(0,180);
    axisY1->setLabelFormat("%d");
    axisY1->setTickCount(15);
    axisY1->setMinorTickCount(0);
    axisY1->setTitleText("角度(°)");

    axisY2->setRange(0,5);
    axisY2->setLabelFormat("%.2f");
    axisY2->setTickCount(11);
    axisY2->setMinorTickCount(0);
    axisY2->setTitleText("电流(A)");
    axisY2->setLabelsVisible(false);
    axisY2->setTitleVisible(false);
    axisY2->setVisible(false);

    chartTor->setAxisY(axisY,series);
    chartAnlCur->setAxisY(axisY1,series1);
    chartAnlCur->setAxisY(axisY2,series2);

}

//更新坐标轴范围
void MainWindow::updateChartTor()
{
    int MaxTor=0,MaxAng=0,MaxCur=0,
    MinTor=0,MinAng=0,MinCur=0;

    MaxTor = ui->widget2->mytorque->m_setdata->setTorMax;
    MaxAng = ui->widget2->mytorque->m_setdata->setAngMax;
    MaxCur = ui->widget2->mytorque->m_setdata->setCurMax;
    MinTor = ui->widget2->mytorque->m_setdata->setTorMin;
    MinAng = ui->widget2->mytorque->m_setdata->setAngMin;
    MinCur = ui->widget2->mytorque->m_setdata->setCurMin;

    axisY->setMax(MaxTor);
    axisY1->setMax(MaxAng);
    axisY2->setMax(MaxCur);
    axisY->setMin(MinTor);
    axisY1->setMin(MinAng);
    axisY2->setMin(MinCur);

    ui->widget2->mytorque->axisY->setMax(MaxTor);
    ui->widget2->mytorque->axisY1->setMax(MaxAng);
    ui->widget2->mytorque->axisY2->setMax(MaxCur);
    ui->widget2->mytorque->axisY->setMin(MinTor);
    ui->widget2->mytorque->axisY1->setMin(MinAng);
    ui->widget2->mytorque->axisY2->setMin(MinCur);

    ui->widget2->mytorque->analysis->axisY1->setMax(MaxTor);
    ui->widget2->mytorque->analysis->axisY2->setMax(MaxAng);
    ui->widget2->mytorque->analysis->axisY3->setMax(MaxCur);
    ui->widget2->mytorque->analysis->axisY1->setMin(MinTor);
    ui->widget2->mytorque->analysis->axisY2->setMin(MinAng);
    ui->widget2->mytorque->analysis->axisY3->setMin(MinCur);
}
void MainWindow::updateChartTor1()
{
    int MaxTor1=0,MaxAng1=0,MaxCur1=0,
    MinTor1=0,MinAng1=0,MinCur1=0;

    MaxTor1 = ui->widget3->mytorque->m_setdata->setTorMax;
    MaxAng1 = ui->widget3->mytorque->m_setdata->setAngMax;
    MaxCur1 = ui->widget3->mytorque->m_setdata->setCurMax;
    MinTor1 = ui->widget3->mytorque->m_setdata->setTorMin;
    MinAng1 = ui->widget3->mytorque->m_setdata->setAngMin;
    MinCur1 = ui->widget3->mytorque->m_setdata->setCurMin;

    axisY->setMax(MaxTor1);
    axisY1->setMax(MaxAng1);
    axisY2->setMax(MaxCur1);
    axisY->setMin(MinTor1);
    axisY1->setMin(MinAng1);
    axisY2->setMin(MinCur1);

    ui->widget3->mytorque->axisY->setMax(MaxTor1);
    ui->widget3->mytorque->axisY1->setMax(MaxAng1);
    ui->widget3->mytorque->axisY2->setMax(MaxCur1);
    ui->widget3->mytorque->axisY->setMin(MinTor1);
    ui->widget3->mytorque->axisY1->setMin(MinAng1);
    ui->widget3->mytorque->axisY2->setMin(MinCur1);

    ui->widget3->mytorque->analysis->axisY1->setMax(MaxTor1);
    ui->widget3->mytorque->analysis->axisY2->setMax(MaxAng1);
    ui->widget3->mytorque->analysis->axisY3->setMax(MaxCur1);
    ui->widget3->mytorque->analysis->axisY1->setMin(MinTor1);
    ui->widget3->mytorque->analysis->axisY2->setMin(MinAng1);
    ui->widget3->mytorque->analysis->axisY3->setMin(MinCur1);
}

//创建录波文件并导入数据，数据随机生成
void MainWindow::createWaveFile()
{
    QString fileName ="a.dat";
    WaveData_t* waveData =new WaveData_t;
    m_WaveFile->Init();
    waveData->BrkOper =BrkOper_On;
    int tor=0,ang=0,cur=0;
    qsrand(QTime(0, 0, 0).secsTo(QTime::currentTime()));//随机数种子
       for(int i=0;i<101;i+=10){//随机赋值chardate
           tor=qrand()%1000;
           ang=qrand()%200;
           cur=qrand()%10;
           waveData->Tor[i]=tor;
           waveData->Ang[i]=ang;
           waveData->Cur[i]=cur;
    }
    m_WaveFile->WaveFileImport(fileName,waveData);
}

void MainWindow::axisY_angel()
{
   axisY1->setLabelsVisible(true);//量程可见性
   axisY1->setTitleVisible(true);//坐标轴可见性
   axisY1->setVisible(true);//坐标轴可见性
   axisY2->setLabelsVisible(false);
   axisY2->setTitleVisible(false);
   axisY2->setVisible(false);

}
void MainWindow::axisY_current()
{
    axisY2->setLabelsVisible(true);
    axisY2->setTitleVisible(true);
    axisY2->setVisible(true);
    axisY1->setLabelsVisible(false);
    axisY1->setTitleVisible(false);
    axisY1->setVisible(false);
}
void MainWindow::dataplot_torque(int n, int m)
{
   series->append(n,m);
   ui->widget2->mytorque->dataplot_torque(n,m);
   ui->widget3->mytorque->dataplot_torque(n,m);
}

void MainWindow::dataplot_angel(int n, int m)
{
    series1->append(n,m);
    ui->widget2->mytorque->dataplot_angel(n,m);
    ui->widget3->mytorque->dataplot_angel(n,m);
}

void MainWindow::dataplot_current(int n, int m)
{
    series2->append(n,m);
    ui->widget2->mytorque->dataplot_current(n,m);
    ui->widget3->mytorque->dataplot_current(n,m);
}

//设置窗口的qss样式
void MainWindow::setWindowStyle()
{

//      QFile file(":/qss/qss/QDarkStyleSheet.qss");
//      QFile file(":/qss/qss/no.qss");
        QFile file(":/qss/qss/blue.qss");
       file.open(QFile::ReadOnly);
       QString styleSheet = tr(file.readAll());
       this->setStyleSheet(styleSheet);
       file.close();
}
void MainWindow::sleep(unsigned int msec)
{
    QTime reachTime=QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<reachTime)
    QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

